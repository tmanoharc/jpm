import React, { useEffect } from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '../store/store';
import { setSelectedProgram } from '../store/slices/appSlice';
import { programs } from '../data/programs';
import SearchFilters from '../components/Dashboard/SearchFilters';
import DashboardStats from '../components/Dashboard/DashboardStats';
import { ExternalLink } from 'lucide-react';

const ProgramDashboard: React.FC = () => {
  const { programId } = useParams<{ programId: string }>();
  const dispatch = useAppDispatch();
  const { selectedProgram } = useAppSelector((state) => state.app);

  useEffect(() => {
    if (programId) {
      const program = programs.find(p => p.id === programId);
      if (program) {
        dispatch(setSelectedProgram(program));
      }
    }
  }, [programId, dispatch]);

  if (!programId || !programs.find(p => p.id === programId)) {
    return <Navigate to="/" replace />;
  }

  const program = programs.find(p => p.id === programId);

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="mb-0">Welcome to {program?.name}</h2>
        <button className="btn btn-outline-primary d-flex align-items-center gap-2">
          View Demand
          <ExternalLink size={16} />
        </button>
      </div>

      <SearchFilters />
      <DashboardStats />
    </div>
  );
};

export default ProgramDashboard;