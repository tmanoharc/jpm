import React from 'react';
import { useAppSelector } from '../store/store';

const Requisition: React.FC = () => {
  const { selectedProgram, user } = useAppSelector((state) => state.app);

  // Check if user has access to requisition page
  if (user?.role === 'Recruiter') {
    return (
      <div className="alert alert-danger">
        <h4>Access Denied</h4>
        <p>You don't have permission to access the Requisition management page.</p>
      </div>
    );
  }

  return (
    <div>
      <h2 className="mb-4">Requisition Management</h2>
      {selectedProgram && (
        <div className="alert alert-info">
          <strong>Current Program:</strong> {selectedProgram.name}
        </div>
      )}
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Open Requisitions</h5>
          <p className="card-text">
            Manage job requisitions and hiring requirements.
          </p>
          <div className="row">
            <div className="col-md-3">
              <div className="card bg-light">
                <div className="card-body text-center">
                  <h3 className="text-primary">25</h3>
                  <p className="mb-0">Open Positions</p>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="card bg-light">
                <div className="card-body text-center">
                  <h3 className="text-success">18</h3>
                  <p className="mb-0">In Progress</p>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="card bg-light">
                <div className="card-body text-center">
                  <h3 className="text-warning">7</h3>
                  <p className="mb-0">Pending Approval</p>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="card bg-light">
                <div className="card-body text-center">
                  <h3 className="text-info">12</h3>
                  <p className="mb-0">Filled This Month</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Requisition;