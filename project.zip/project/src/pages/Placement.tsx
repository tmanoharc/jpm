import React from 'react';
import { useAppSelector } from '../store/store';

const Placement: React.FC = () => {
  const { selectedProgram } = useAppSelector((state) => state.app);

  return (
    <div>
      <h2 className="mb-4">Placement Management</h2>
      {selectedProgram && (
        <div className="alert alert-info">
          <strong>Current Program:</strong> {selectedProgram.name}
        </div>
      )}
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Placement Dashboard</h5>
          <p className="card-text">
            Manage and track candidate placements across different programs.
          </p>
          <div className="row">
            <div className="col-md-4">
              <div className="card bg-light">
                <div className="card-body text-center">
                  <h3 className="text-primary">45</h3>
                  <p className="mb-0">Active Placements</p>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card bg-light">
                <div className="card-body text-center">
                  <h3 className="text-success">32</h3>
                  <p className="mb-0">Successful Placements</p>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card bg-light">
                <div className="card-body text-center">
                  <h3 className="text-warning">13</h3>
                  <p className="mb-0">Pending Reviews</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Placement;