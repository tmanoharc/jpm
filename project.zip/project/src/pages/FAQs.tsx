import React from 'react';
import { useAppSelector } from '../store/store';

const FAQs: React.FC = () => {
  const { selectedProgram } = useAppSelector((state) => state.app);

  const faqs = [
    {
      question: 'How do I submit a new candidate?',
      answer: 'Navigate to the Candidates section and click on "Add New Candidate" button. Fill in the required information and submit for review.',
    },
    {
      question: 'What are the different program stages?',
      answer: 'Each program has multiple stages including Application Review, Initial Interview, Technical Assessment, Final Interview, and Placement.',
    },
    {
      question: 'How do I track candidate progress?',
      answer: 'Use the dashboard to monitor candidate status and progress through different stages of the recruitment process.',
    },
    {
      question: 'Who can approve requisitions?',
      answer: 'Only Hiring Managers, Program Managers, and Admins have the authority to approve new requisitions.',
    },
  ];

  return (
    <div>
      <h2 className="mb-4">Frequently Asked Questions</h2>
      {selectedProgram && (
        <div className="alert alert-info">
          <strong>Current Program:</strong> {selectedProgram.name}
        </div>
      )}
      <div className="accordion" id="faqAccordion">
        {faqs.map((faq, index) => (
          <div key={index} className="accordion-item">
            <h2 className="accordion-header" id={`heading${index}`}>
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target={`#collapse${index}`}
                aria-expanded="false"
                aria-controls={`collapse${index}`}
              >
                {faq.question}
              </button>
            </h2>
            <div
              id={`collapse${index}`}
              className="accordion-collapse collapse"
              aria-labelledby={`heading${index}`}
              data-bs-parent="#faqAccordion"
            >
              <div className="accordion-body">
                {faq.answer}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FAQs;