import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppDispatch } from '../store/store';
import { setSelectedProgram } from '../store/slices/appSlice';
import { programs } from '../data/programs';
import ProgramCard from '../components/ProgramCard';
import { Program } from '../types';
import { Search } from 'lucide-react';

const ProgramSelection: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const handleProgramSelect = (program: Program) => {
    dispatch(setSelectedProgram(program));
    navigate(program.route);
  };

  return (
    <div className="min-vh-100 bg-light">
      <div className="container py-5">
        <div className="text-center mb-5">
          <h1 className="display-4 fw-bold mb-4" style={{ fontSize: '3.5rem' }}>
            Welcome to TalentMatch360
          </h1>
          <div className="row justify-content-center mb-5">
            <div className="col-md-6">
              <h5 className="text-dark mb-4">Please select your Program</h5>
              <div className="position-relative">
                <input
                  type="text"
                  className="form-control form-control-lg border-0 shadow-sm"
                  placeholder="Search"
                  style={{ paddingLeft: '50px' }}
                />
                <Search
                  size={20}
                  className="position-absolute text-muted"
                  style={{ left: '15px', top: '50%', transform: 'translateY(-50%)' }}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="row g-4">
          {programs.map((program) => (
            <div key={program.id} className="col-md-6 col-lg-3">
              <ProgramCard program={program} onClick={handleProgramSelect} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProgramSelection;