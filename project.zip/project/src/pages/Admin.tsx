import React from 'react';
import { useAppSelector, useAppDispatch } from '../store/store';
import { setUser } from '../store/slices/appSlice';
import { UserRole } from '../types';

const Admin: React.FC = () => {
  const { user } = useAppSelector((state) => state.app);
  const dispatch = useAppDispatch();

  if (user?.role !== 'Admin') {
    return (
      <div className="alert alert-danger">
        <h4>Access Denied</h4>
        <p>You don't have permission to access the Admin panel.</p>
      </div>
    );
  }

  const handleRoleChange = (newRole: UserRole) => {
    if (user) {
      dispatch(setUser({ ...user, role: newRole }));
    }
  };

  return (
    <div>
      <h2 className="mb-4">Admin Panel</h2>
      <div className="row">
        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Role Management</h5>
              <p className="card-text">
                Current Role: <span className="badge bg-primary">{user?.role}</span>
              </p>
              <div className="mb-3">
                <label className="form-label">Switch Role (Demo Purpose):</label>
                <select
                  className="form-select"
                  value={user?.role || ''}
                  onChange={(e) => handleRoleChange(e.target.value as UserRole)}
                >
                  <option value="Admin">Admin</option>
                  <option value="Recruiter">Recruiter</option>
                  <option value="Hiring Manager">Hiring Manager</option>
                  <option value="Program Manager">Program Manager</option>
                </select>
              </div>
              <small className="text-muted">
                Switch roles to see how the application behaves differently for each role.
              </small>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">System Statistics</h5>
              <div className="row">
                <div className="col-6">
                  <div className="text-center">
                    <h4 className="text-primary">4</h4>
                    <small>Active Programs</small>
                  </div>
                </div>
                <div className="col-6">
                  <div className="text-center">
                    <h4 className="text-success">156</h4>
                    <small>Total Users</small>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admin;