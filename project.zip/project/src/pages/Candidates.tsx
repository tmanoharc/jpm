import React from 'react';
import { useAppSelector } from '../store/store';

const Candidates: React.FC = () => {
  const { selectedProgram, isReadOnlyMode } = useAppSelector((state) => state.app);

  return (
    <div>
      <h2 className="mb-4">Candidate Management</h2>
      {selectedProgram && (
        <div className="alert alert-info">
          <strong>Current Program:</strong> {selectedProgram.name}
        </div>
      )}
      {isReadOnlyMode && (
        <div className="alert alert-warning">
          <strong>Read-only mode:</strong> You have limited access to candidate information.
        </div>
      )}
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Candidate Pipeline</h5>
          <p className="card-text">
            Track and manage candidates throughout the recruitment process.
          </p>
          <div className="table-responsive">
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Status</th>
                  <th>Program</th>
                  <th>Stage</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>John Smith</td>
                  <td><span className="badge bg-success">Active</span></td>
                  <td>{selectedProgram?.name || 'N/A'}</td>
                  <td>Interview</td>
                  <td>
                    <button className="btn btn-sm btn-outline-primary" disabled={isReadOnlyMode}>
                      View
                    </button>
                  </td>
                </tr>
                <tr>
                  <td>Jane Doe</td>
                  <td><span className="badge bg-warning">Pending</span></td>
                  <td>{selectedProgram?.name || 'N/A'}</td>
                  <td>Review</td>
                  <td>
                    <button className="btn btn-sm btn-outline-primary" disabled={isReadOnlyMode}>
                      View
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Candidates;