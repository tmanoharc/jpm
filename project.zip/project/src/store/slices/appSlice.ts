import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { User, Program, AppState } from '../../types';

const initialState: AppState = {
  user: {
    id: '1',
    name: 'John Doe',
    email: 'john.doe@example.com',
    role: 'Admin', // Default to Admin for demo
  },
  selectedProgram: null,
  sidebarCollapsed: false,
  isReadOnlyMode: false,
};

const appSlice = createSlice({
  name: 'app',
  initialState,
  reducers: {
    setUser: (state, action: PayloadAction<User>) => {
      state.user = action.payload;
      // Set read-only mode for Recruiter role
      state.isReadOnlyMode = action.payload.role === 'Recruiter';
    },
    setSelectedProgram: (state, action: PayloadAction<Program>) => {
      state.selectedProgram = action.payload;
    },
    toggleSidebar: (state) => {
      state.sidebarCollapsed = !state.sidebarCollapsed;
    },
    setReadOnlyMode: (state, action: PayloadAction<boolean>) => {
      state.isReadOnlyMode = action.payload;
    },
    clearSelectedProgram: (state) => {
      state.selectedProgram = null;
    },
  },
});

export const {
  setUser,
  setSelectedProgram,
  toggleSidebar,
  setReadOnlyMode,
  clearSelectedProgram,
} = appSlice.actions;

export default appSlice.reducer;