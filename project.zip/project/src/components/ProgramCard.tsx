import React from 'react';
import { Program } from '../types';
import { ArrowRight } from 'lucide-react';

interface ProgramCardProps {
  program: Program;
  onClick: (program: Program) => void;
}

const ProgramCard: React.FC<ProgramCardProps> = ({ program, onClick }) => {
  return (
    <div
      className="card h-100 border-0 shadow-sm hover-shadow program-card"
      style={{
        backgroundColor: program.color,
        cursor: 'pointer',
        transition: 'all 0.3s ease',
      }}
      onClick={() => onClick(program)}
    >
      <div className="card-body d-flex flex-column p-4">
        <div className="d-flex justify-content-between align-items-start mb-3">
          <h4 className="card-title fw-bold text-primary mb-0">{program.name}</h4>
          <ArrowRight size={20} className="text-muted" />
        </div>
        <h6 className="card-subtitle mb-3 text-dark fw-medium">{program.title}</h6>
        <p className="card-text text-muted flex-grow-1" style={{ fontSize: '14px', lineHeight: '1.5' }}>
          {program.description}
        </p>
      </div>
    </div>
  );
};

export default ProgramCard;