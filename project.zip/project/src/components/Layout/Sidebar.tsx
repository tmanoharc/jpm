import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAppSelector } from '../../store/store';
import { Home, Users, FileText, UserCheck, HelpCircle, Settings } from 'lucide-react';

interface NavItem {
  path: string;
  label: string;
  icon: React.ReactNode;
  roles: string[];
}

const Sidebar: React.FC = () => {
  const { sidebarCollapsed, user, selectedProgram } = useAppSelector((state) => state.app);
  const navigate = useNavigate();

  const navItems: NavItem[] = [
    {
      path: selectedProgram ? `/program/${selectedProgram.id}` : '/',
      label: 'Home',
      icon: <Home size={20} />,
      roles: ['Admin', 'Recruiter', 'Hiring Manager', 'Program Manager'],
    },
    {
      path: selectedProgram ? `/program/${selectedProgram.id}/placement` : '/placement',
      label: 'Placement',
      icon: <FileText size={20} />,
      roles: ['Admin', 'Recruiter', 'Hiring Manager', 'Program Manager'],
    },
    {
      path: selectedProgram ? `/program/${selectedProgram.id}/candidates` : '/candidates',
      label: 'Candidates',
      icon: <Users size={20} />,
      roles: ['Admin', 'Recruiter', 'Hiring Manager', 'Program Manager'],
    },
    {
      path: selectedProgram ? `/program/${selectedProgram.id}/requisition` : '/requisition',
      label: 'Requisition',
      icon: <UserCheck size={20} />,
      roles: ['Admin', 'Hiring Manager', 'Program Manager'],
    },
    {
      path: selectedProgram ? `/program/${selectedProgram.id}/faqs` : '/faqs',
      label: 'FAQs',
      icon: <HelpCircle size={20} />,
      roles: ['Admin', 'Recruiter', 'Hiring Manager', 'Program Manager'],
    },
    {
      path: '/admin',
      label: 'Admin',
      icon: <Settings size={20} />,
      roles: ['Admin'],
    },
  ];

  const filteredNavItems = navItems.filter((item) => 
    user && item.roles.includes(user.role)
  );

  const handleLogoClick = () => {
    navigate('/');
  };

  return (
    <div
      className={`bg-light border-end h-100 transition-all ${
        sidebarCollapsed ? 'sidebar-collapsed' : 'sidebar-expanded'
      }`}
      style={{
        width: sidebarCollapsed ? '60px' : '250px',
        transition: 'width 0.3s ease',
        minHeight: '100vh',
      }}
    >
      {!sidebarCollapsed && (
        <div className="p-3 border-bottom">
          <button
            className="btn btn-link p-0 text-decoration-none"
            onClick={handleLogoClick}
          >
            <span className="fw-bold text-primary">Company Logo</span>
          </button>
        </div>
      )}
      
      <nav className="py-3">
        {filteredNavItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `d-flex align-items-center px-3 py-2 text-decoration-none text-dark hover-bg-light ${
                isActive ? 'bg-primary text-white' : ''
              }`
            }
            style={{ minHeight: '40px' }}
          >
            <span className="d-flex align-items-center justify-content-center" style={{ width: '20px' }}>
              {item.icon}
            </span>
            {!sidebarCollapsed && (
              <span className="ms-3">{item.label}</span>
            )}
          </NavLink>
        ))}
      </nav>
    </div>
  );
};

export default Sidebar;