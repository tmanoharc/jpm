import React from 'react';
import { useAppDispatch, useAppSelector } from '../../store/store';
import { toggleSidebar } from '../../store/slices/appSlice';
import { Menu, User } from 'lucide-react';

const Header: React.FC = () => {
  const dispatch = useAppDispatch();
  const { selectedProgram, user } = useAppSelector((state) => state.app);

  const handleToggleSidebar = () => {
    dispatch(toggleSidebar());
  };

  return (
    <header className="bg-white border-bottom shadow-sm">
      <div className="container-fluid">
        <div className="row align-items-center py-2">
          <div className="col-auto">
            <button
              className="btn btn-link p-0 border-0"
              onClick={handleToggleSidebar}
              style={{ color: '#666' }}
            >
              <Menu size={24} />
            </button>
          </div>
          <div className="col">
            <div className="d-flex align-items-center">
              <span className="fw-bold text-dark me-2">TalentMatch360</span>
              {selectedProgram && (
                <>
                  <span className="text-muted mx-2">-</span>
                  <span className="text-primary fw-medium">{selectedProgram.name}</span>
                </>
              )}
            </div>
          </div>
          <div className="col-auto">
            <div className="d-flex align-items-center">
              <User size={20} className="me-2 text-muted" />
              <span className="text-dark fw-medium">{user?.name}</span>
              <span className="badge bg-secondary ms-2">{user?.role}</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;