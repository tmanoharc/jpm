import React from 'react';

interface StatsCardProps {
  icon: React.ReactNode;
  title: string;
  value: number;
  color?: string;
}

const StatsCard: React.FC<StatsCardProps> = ({ icon, title, value, color = '#6c757d' }) => {
  return (
    <div className="d-flex align-items-center p-3 bg-light rounded mb-3">
      <div
        className="d-flex align-items-center justify-content-center rounded-circle me-3"
        style={{
          width: '48px',
          height: '48px',
          backgroundColor: `${color}20`,
          color: color,
        }}
      >
        {icon}
      </div>
      <div>
        <div className="text-muted small">{title}</div>
        <div className="fw-bold fs-4">{value}</div>
      </div>
    </div>
  );
};

export default StatsCard;