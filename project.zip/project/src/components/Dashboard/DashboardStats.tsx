import React from 'react';
import StatsCard from './StatsCard';
import { FileText, Users, Clock, CheckCircle, RefreshCw, Phone, Star, Target } from 'lucide-react';

const DashboardStats: React.FC = () => {
  return (
    <div className="row">
      <div className="col-md-4">
        <h5 className="mb-3">Requisition Details</h5>
        <StatsCard icon={<FileText size={20} />} title="In Progress" value={100} color="#198754" />
        <StatsCard icon={<RefreshCw size={20} />} title="Intake Pending" value={28} color="#fd7e14" />
        <StatsCard icon={<CheckCircle size={20} />} title="Ready to Match" value={72} color="#0d6efd" />
        <StatsCard icon={<Target size={20} />} title="Filled" value={20} color="#6c757d" />
      </div>
      
      <div className="col-md-4">
        <h5 className="mb-3">Candidate Details</h5>
        <StatsCard icon={<Users size={20} />} title="In Progress" value={100} color="#198754" />
        <StatsCard icon={<Clock size={20} />} title="Intake Pending" value={20} color="#fd7e14" />
        <StatsCard icon={<RefreshCw size={20} />} title="Offer Extension Pending" value={14} color="#dc3545" />
        <StatsCard icon={<CheckCircle size={20} />} title="Ready to Match" value={56} color="#0d6efd" />
      </div>
      
      <div className="col-md-4">
        <div className="mb-4">
          <StatsCard icon={<RefreshCw size={20} />} title="Match Approval Pending" value={40} color="#6f42c1" />
          <StatsCard icon={<Phone size={20} />} title="Calls to Schedule" value={14} color="#20c997" />
        </div>
        <div>
          <StatsCard icon={<Star size={20} />} title="Future Talent" value={12} color="#ffc107" />
          <StatsCard icon={<Target size={20} />} title="Ready to Place" value={20} color="#0dcaf0" />
        </div>
      </div>
    </div>
  );
};

export default DashboardStats;