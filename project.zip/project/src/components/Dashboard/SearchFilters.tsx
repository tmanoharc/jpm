import React, { useState } from 'react';
import { useAppSelector } from '../../store/store';

const SearchFilters: React.FC = () => {
  const { isReadOnlyMode } = useAppSelector((state) => state.app);
  const [filters, setFilters] = useState({
    field1: '',
    country: 'India',
    field3: '',
    field4: '',
    field5: '',
    field6: '',
    field7: '',
    field8: '',
  });

  const handleInputChange = (field: string, value: string) => {
    if (!isReadOnlyMode) {
      setFilters(prev => ({ ...prev, [field]: value }));
    }
  };

  const handleReset = () => {
    if (!isReadOnlyMode) {
      setFilters({
        field1: '',
        country: 'India',
        field3: '',
        field4: '',
        field5: '',
        field6: '',
        field7: '',
        field8: '',
      });
    }
  };

  const handleShowResult = () => {
    if (!isReadOnlyMode) {
      console.log('Showing results with filters:', filters);
    }
  };

  return (
    <div className="mb-4">
      <div className="row g-3 mb-3">
        <div className="col-md-2">
          <label className="form-label text-muted small">Field label</label>
          <select
            className="form-select"
            value={filters.field1}
            onChange={(e) => handleInputChange('field1', e.target.value)}
            disabled={isReadOnlyMode}
          >
            <option value="">Text</option>
            <option value="option1">Option 1</option>
            <option value="option2">Option 2</option>
          </select>
        </div>
        <div className="col-md-2">
          <label className="form-label text-muted small">Country</label>
          <select
            className="form-select"
            value={filters.country}
            onChange={(e) => handleInputChange('country', e.target.value)}
            disabled={isReadOnlyMode}
          >
            <option value="India">India</option>
            <option value="USA">USA</option>
            <option value="UK">UK</option>
          </select>
        </div>
        <div className="col-md-2">
          <label className="form-label text-muted small">Field label</label>
          <select
            className="form-select"
            value={filters.field3}
            onChange={(e) => handleInputChange('field3', e.target.value)}
            disabled={isReadOnlyMode}
          >
            <option value="">Text</option>
            <option value="option1">Option 1</option>
            <option value="option2">Option 2</option>
          </select>
        </div>
        <div className="col-md-2">
          <label className="form-label text-muted small">Field label</label>
          <select
            className="form-select"
            value={filters.field4}
            onChange={(e) => handleInputChange('field4', e.target.value)}
            disabled={isReadOnlyMode}
          >
            <option value="">Text</option>
            <option value="option1">Option 1</option>
            <option value="option2">Option 2</option>
          </select>
        </div>
        <div className="col-md-2">
          <label className="form-label text-muted small">Field label</label>
          <select
            className="form-select"
            value={filters.field5}
            onChange={(e) => handleInputChange('field5', e.target.value)}
            disabled={isReadOnlyMode}
          >
            <option value="">Text</option>
            <option value="option1">Option 1</option>
            <option value="option2">Option 2</option>
          </select>
        </div>
      </div>
      
      <div className="row g-3 mb-3">
        <div className="col-md-2">
          <label className="form-label text-muted small">Field label</label>
          <select
            className="form-select"
            value={filters.field6}
            onChange={(e) => handleInputChange('field6', e.target.value)}
            disabled={isReadOnlyMode}
          >
            <option value="">Text</option>
            <option value="option1">Option 1</option>
            <option value="option2">Option 2</option>
          </select>
        </div>
        <div className="col-md-2">
          <label className="form-label text-muted small">Field label</label>
          <select
            className="form-select"
            value={filters.field7}
            onChange={(e) => handleInputChange('field7', e.target.value)}
            disabled={isReadOnlyMode}
          >
            <option value="">Text</option>
            <option value="option1">Option 1</option>
            <option value="option2">Option 2</option>
          </select>
        </div>
        <div className="col-md-2">
          <label className="form-label text-muted small">Field label</label>
          <select
            className="form-select"
            value={filters.field8}
            onChange={(e) => handleInputChange('field8', e.target.value)}
            disabled={isReadOnlyMode}
          >
            <option value="">Text</option>
            <option value="option1">Option 1</option>
            <option value="option2">Option 2</option>
          </select>
        </div>
        <div className="col-md-2">
          <label className="form-label text-muted small">Field label</label>
          <select
            className="form-select"
            value={filters.field8}
            onChange={(e) => handleInputChange('field8', e.target.value)}
            disabled={isReadOnlyMode}
          >
            <option value="">Text</option>
            <option value="option1">Option 1</option>
            <option value="option2">Option 2</option>
          </select>
        </div>
        <div className="col-md-4 d-flex align-items-end gap-2">
          <button
            className="btn btn-outline-secondary"
            onClick={handleReset}
            disabled={isReadOnlyMode}
          >
            Reset
          </button>
          <button
            className="btn btn-dark"
            onClick={handleShowResult}
            disabled={isReadOnlyMode}
          >
            Show Result
          </button>
        </div>
      </div>
      
      {isReadOnlyMode && (
        <div className="alert alert-info small mb-3">
          <strong>Read-only mode:</strong> Search controls are disabled for Recruiter role.
        </div>
      )}
    </div>
  );
};

export default SearchFilters;