import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from './store/store';
import Layout from './components/Layout/Layout';
import ProgramSelection from './pages/ProgramSelection';
import ProgramDashboard from './pages/ProgramDashboard';
import Placement from './pages/Placement';
import Candidates from './pages/Candidates';
import Requisition from './pages/Requisition';
import FAQs from './pages/FAQs';
import Admin from './pages/Admin';
import 'bootstrap/dist/css/bootstrap.min.css';

const App: React.FC = () => {
  return (
    <Provider store={store}>
      <Router>
        <Routes>
          <Route path="/" element={<ProgramSelection />} />
          <Route path="/" element={<Layout />}>
            <Route path="/program/:programId" element={<ProgramDashboard />} />
            <Route path="/program/:programId/placement" element={<Placement />} />
            <Route path="/program/:programId/candidates" element={<Candidates />} />
            <Route path="/program/:programId/requisition" element={<Requisition />} />
            <Route path="/program/:programId/faqs" element={<FAQs />} />
            <Route path="/placement" element={<Placement />} />
            <Route path="/candidates" element={<Candidates />} />
            <Route path="/requisition" element={<Requisition />} />
            <Route path="/faqs" element={<FAQs />} />
            <Route path="/admin" element={<Admin />} />
          </Route>
        </Routes>
      </Router>
    </Provider>
  );
};

export default App;