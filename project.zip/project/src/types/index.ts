export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

export type UserRole = 'Admin' | 'Recruiter' | 'Hiring Manager' | 'Program Manager';

export interface Program {
  id: string;
  name: string;
  title: string;
  description: string;
  color: string;
  route: string;
}

export interface AppState {
  user: User | null;
  selectedProgram: Program | null;
  sidebarCollapsed: boolean;
  isReadOnlyMode: boolean;
}

export interface DashboardStats {
  requisitionDetails: {
    inProgress: number;
    intakePending: number;
    readyToMatch: number;
    filled: number;
  };
  candidateDetails: {
    inProgress: number;
    intakePending: number;
    offerExtensionPending: number;
    readyToMatch: number;
  };
  additionalStats: {
    matchApprovalPending: number;
    callsToSchedule: number;
    futureTalent: number;
    readyToPlace: number;
  };
}