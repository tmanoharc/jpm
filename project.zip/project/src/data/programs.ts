import { Program } from '../types';

export const programs: Program[] = [
  {
    id: 'cadp',
    name: 'CADP',
    title: 'Corporate Analyst Development Program',
    description: 'The CADP is a 2-year program where analysts rotate through 3 of 4 disciplines that are sourced across all Risk/Financial Centers and LOBs.',
    color: '#f8f9fa',
    route: '/program/cadp',
  },
  {
    id: 'hradp',
    name: 'HRADP',
    title: 'Human Resource Analyst Development Program',
    description: 'HRADP - It is a 2 year rotational analyst program that provides a pipeline of well-rounded future leaders with core business skills for a variety...',
    color: '#f8f9fa',
    route: '/program/hradp',
  },
  {
    id: 'cohort-hiring',
    name: 'Cohort Hiring',
    title: 'Cohort Hiring',
    description: 'Cohort Hiring is a skill-based talent acquisition and onboarding service for software engineers that focuses on quality, efficiency and a great experience for candidates, enablers and hiring managers.',
    color: '#f8f9fa',
    route: '/program/cohort-hiring',
  },
  {
    id: 'sep',
    name: 'SEP',
    title: 'Software Engineer Program',
    description: 'A 2-year permanent hire, non-rotational career development program that provides junior talent with foundational skills and experience to transition them to establish successful careers in Technology at JPMorganChase.',
    color: '#f8f9fa',
    route: '/program/sep',
  },
];